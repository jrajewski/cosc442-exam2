package megamek.server.commands;

import org.junit.*;
import megamek.server.Server;
import static org.junit.Assert.*;

/**
 * The class <code>ListSavesCommandTest</code> contains tests for the class <code>{@link ListSavesCommand}</code>.
 *
 * @generatedBy CodePro at 5/18/17 2:01 PM
 * @author jrajew1
 * @version $Revision: 1.0 $
 */
public class ListSavesCommandTest {
	/**
	 * Run the ListSavesCommand(Server) constructor test.
	 *
	 * @throws Exception
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	/**
	 * Perform pre-test initialization.
	 *
	 * @throws Exception
	 *         if the initialization fails for some reason
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@Before
	public void setUp()
		throws Exception {
		// add additional set up code here
		Server server1 = Server.getServerInstance();
		ListSavesCommand lsc = new ListSavesCommand(server1);
	}
	
	@Test
	public void testListSavesCommand_1()
		throws Exception {
		Server server = Server.getServerInstance();

		ListSavesCommand result = new ListSavesCommand(server);

		// add additional test code here
		assertNotNull(result);
		assertEquals("listSaves", result.getName());
		assertEquals("List all saved games in the saved games directory.", result.getHelp());
	}

	/**
	 * Run the void run(int,String[]) method test.
	 *
	 * @throws Exception
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@Test
	public void testRun_1()
		throws Exception {
		ListSavesCommand fixture = new ListSavesCommand(Server.getServerInstance());
		fixture.server = Server.getServerInstance();
		int connId = 1;
		String[] args = new String[] {};
		Server server1 = Server.getServerInstance();
		ListSavesCommand lsc = new ListSavesCommand(server1);
		lsc.run(connId, args);

		// add additional test code here
		// An unexpected exception was thrown in user code while executing this test:
		//    java.lang.NullPointerException
		//       at megamek.server.commands.ListSavesCommand.run(ListSavesCommand.java:44)
	}

	/**
	 * Run the void run(int,String[]) method test.
	 *
	 * @throws Exception
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@Test
	public void testRun_2()
		throws Exception {
		ListSavesCommand fixture = new ListSavesCommand(Server.getServerInstance());
		fixture.server = Server.getServerInstance();
		int connId = 1;
		String[] args = new String[] {};

		fixture.run(connId, args);

		// add additional test code here
		// An unexpected exception was thrown in user code while executing this test:
		//    java.lang.NullPointerException
		//       at megamek.server.commands.ListSavesCommand.run(ListSavesCommand.java:44)
	}

	/**
	 * Run the void run(int,String[]) method test.
	 *
	 * @throws Exception
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@Test
	public void testRun_3()
		throws Exception {
		ListSavesCommand fixture = new ListSavesCommand(Server.getServerInstance());
		fixture.server = Server.getServerInstance();
		int connId = 1;
		String[] args = new String[] {};

		fixture.run(connId, args);

		// add additional test code here
		// An unexpected exception was thrown in user code while executing this test:
		//    java.lang.NullPointerException
		//       at megamek.server.commands.ListSavesCommand.run(ListSavesCommand.java:44)
	}

	/**
	 * Run the void run(int,String[]) method test.
	 *
	 * @throws Exception
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@Test
	public void testRun_4()
		throws Exception {
		ListSavesCommand fixture = new ListSavesCommand(Server.getServerInstance());
		fixture.server = Server.getServerInstance();
		int connId = 1;
		String[] args = new String[] {};

		fixture.run(connId, args);

		// add additional test code here
		// An unexpected exception was thrown in user code while executing this test:
		//    java.lang.NullPointerException
		//       at megamek.server.commands.ListSavesCommand.run(ListSavesCommand.java:44)
	}

	/**
	 * Run the void run(int,String[]) method test.
	 *
	 * @throws Exception
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@Test
	public void testRun_5()
		throws Exception {
		ListSavesCommand fixture = new ListSavesCommand(Server.getServerInstance());
		fixture.server = Server.getServerInstance();
		int connId = 1;
		String[] args = new String[] {};

		fixture.run(connId, args);

		// add additional test code here
		// An unexpected exception was thrown in user code while executing this test:
		//    java.lang.NullPointerException
		//       at megamek.server.commands.ListSavesCommand.run(ListSavesCommand.java:44)
	}

	/**
	 * Run the void run(int,String[]) method test.
	 *
	 * @throws Exception
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@Test
	public void testRun_6()
		throws Exception {
		ListSavesCommand fixture = new ListSavesCommand(Server.getServerInstance());
		fixture.server = Server.getServerInstance();
		int connId = 1;
		String[] args = new String[] {};

		fixture.run(connId, args);

		// add additional test code here
		// An unexpected exception was thrown in user code while executing this test:
		//    java.lang.NullPointerException
		//       at megamek.server.commands.ListSavesCommand.run(ListSavesCommand.java:44)
	}

	/**
	 * Run the void run(int,String[]) method test.
	 *
	 * @throws Exception
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@Test
	public void testRun_7()
		throws Exception {
		ListSavesCommand fixture = new ListSavesCommand(Server.getServerInstance());
		fixture.server = Server.getServerInstance();
		int connId = 1;
		String[] args = new String[] {};
		fixture.run(connId, args);

		// add additional test code here
		// An unexpected exception was thrown in user code while executing this test:
		//    java.lang.NullPointerException
		//       at megamek.server.commands.ListSavesCommand.run(ListSavesCommand.java:44)
	}

	/**
	 * Run the void run(int,String[]) method test.
	 *
	 * @throws Exception
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@Test
	public void testRun_8()
		throws Exception {
		ListSavesCommand fixture = new ListSavesCommand(Server.getServerInstance());
		fixture.server = Server.getServerInstance();
		int connId = 1;
		String[] args = new String[] {};

		fixture.run(connId, args);

		// add additional test code here
		// An unexpected exception was thrown in user code while executing this test:
		//    java.lang.NullPointerException
		//       at megamek.server.commands.ListSavesCommand.run(ListSavesCommand.java:44)
	}

	/**
	 * Run the void run(int,String[]) method test.
	 *
	 * @throws Exception
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@Test
	public void testRun_9()
		throws Exception {
		ListSavesCommand fixture = new ListSavesCommand(Server.getServerInstance());
		fixture.server = Server.getServerInstance();
		int connId = 1;
		String[] args = new String[] {};

		fixture.run(connId, args);

		// add additional test code here
		// An unexpected exception was thrown in user code while executing this test:
		//    java.lang.NullPointerException
		//       at megamek.server.commands.ListSavesCommand.run(ListSavesCommand.java:44)
	}

	/**
	 * Run the void run(int,String[]) method test.
	 *
	 * @throws Exception
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@Test
	public void testRun_10()
		throws Exception {
		ListSavesCommand fixture = new ListSavesCommand(Server.getServerInstance());
		fixture.server = Server.getServerInstance();
		int connId = 1;
		String[] args = new String[] {};

		fixture.run(connId, args);

		// add additional test code here
		// An unexpected exception was thrown in user code while executing this test:
		//    java.lang.NullPointerException
		//       at megamek.server.commands.ListSavesCommand.run(ListSavesCommand.java:44)
	}

	

	/**
	 * Perform post-test clean-up.
	 *
	 * @throws Exception
	 *         if the clean-up fails for some reason
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	@After
	public void tearDown()
		throws Exception {
		// Add additional tear down code here
	}

	/**
	 * Launch the test.
	 *
	 * @param args the command line arguments
	 *
	 * @generatedBy CodePro at 5/18/17 2:01 PM
	 */
	public static void main(String[] args) {
		new org.junit.runner.JUnitCore().run(ListSavesCommandTest.class);
	}
}